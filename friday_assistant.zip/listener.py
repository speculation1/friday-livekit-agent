import os
import time
import speech_recognition as sr

WAKE_WORD = "hey friday"

def speak(text):
    os.system(f'termux-tts-speak "{text}"')

def listen_and_recognize():
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        print("🎙️ Listening for wake word...")
        audio = recognizer.listen(source)

    try:
        query = recognizer.recognize_google(audio)
        print("You said:", query)
        return query.lower()
    except sr.UnknownValueError:
        print("❌ Could not understand.")
    except sr.RequestError:
        print("⚠️ Google API unavailable.")
    return ""

def record_command():
    speak("Yes Austin? I’m listening.")
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        print("🎧 Waiting for your command...")
        audio = recognizer.listen(source)
    try:
        command = recognizer.recognize_google(audio)
        print("📢 Command:", command)
        return command
    except sr.UnknownValueError:
        return "Sorry, I didn't catch that."
    except sr.RequestError:
        return "Sorry, my brain is offline right now."

# 🔁 Loop
while True:
    query = listen_and_recognize()
    if WAKE_WORD in query:
        response = record_command()
        speak(response)
    time.sleep(1)

